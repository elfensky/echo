// $("#submit_form").on('click', function(){
// 	// var departments = 

// 	// var departments = $("[name='department[]']").serialize()
// 	// console.log(departments);

// 	// var type = $("[name='type[]']").serialize()
// 	// console.log(type[0]);

// 	var author
// });